import React from 'react';

const PasswordForget = () => (
  <div>
    <h1>PasswordForget</h1>
  </div>
);

export default PasswordForget;
